# Curso de NLP Alura, Construindo um corretor ortográfico utilizando python
